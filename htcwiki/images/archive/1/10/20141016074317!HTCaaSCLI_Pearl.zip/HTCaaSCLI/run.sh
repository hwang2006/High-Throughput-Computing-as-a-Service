

  cmd="java "
  cmd=$cmd" -classpath"

  #cmd=$cmd" build"
  cmd=$cmd" client.jar"

  cmd=$cmd":conf"

  cmd=$cmd":lib/htcaas_web.jar"

  cmd=$cmd":lib/bcprov-jdk16-146.jar"
  cmd=$cmd":lib/commons-cli-1.2.jar"
  cmd=$cmd":lib/commons-lang-2.6.jar"
  cmd=$cmd":lib/commons-net-3.0.1.jar"
  cmd=$cmd":lib/cxf-2.2.8.jar"
  cmd=$cmd":lib/log4j-1.2.16.jar"
  cmd=$cmd":lib/mail-1.4.3.jar"
  cmd=$cmd":lib/slf4j-api-1.5.8.jar"
  cmd=$cmd":lib/slf4j-log4j12-1.5.8.jar"
  cmd=$cmd":lib/wsdl4j-1.6.2.jar"
  cmd=$cmd":lib/XmlSchema-1.4.5.jar"
  cmd=$cmd":lib/jline-1.0-new.jar"
  cmd=$cmd":lib/cog-jglobus-1.8.0.jar"
  cmd=$cmd":lib/commons-io-2.0.1.jar"
  cmd=$cmd":lib/commons-logging-1.1.jar"
  cmd=$cmd":lib/cryptix.jar"
  cmd=$cmd":lib/crptix32.jar"
  cmd=$cmd":lib/cryptix-asn1.jar"
  cmd=$cmd":lib/puretls.jar"
  cmd=$cmd":client.jar"
  cmd=$cmd":lib/HTCaaS_proxy_v1.3.jar"

  #cmd=$cmd":../HTCaaS_proxy/build"

  cmd=$cmd" kr/re/kisti/htcaascli/HTCaasCLI "$@

#echo $cmd

  $cmd




